package IsfarMethodMadnessFinal;

public class testFile {

    public static void main(String[] args) {
        System.out.println("Is it a palindrome? True or false? " +IOshirLib.isPalindrome("racecar"));                    //This is to check if a word is a palindrome.
        System.out.println("The date is: " + IOshirLib.dateStr("01/08/1999"));                                          //This changes the format of the date from month-day to day-month.
        System.out.println("The sum is " + IOshirLib.sumIntegers(4));                                                       //This takes the sum of integers from 0 to some integer value.
        System.out.println("The final word is " + IOshirLib.cutOut("catatonic cat", "cat"));                    //This takes allows you to remove a subset of letters from a particular word.
        System.out.println("End: " + IOshirLib.multiplicationTable(4, 5));                                              //This takes one integer and makes a table of products of that specific integer and other numbers up to a certain value.
        System.out.println(IOshirLib.quadSolver(1,1,1));                                                             //This uses the quadratic formula to find the roots of a quadratic equation.
    }
}